// import { asserts, superoak } from '../../../deps.js';
// import { app } from '../../../app.js';

// Deno.test("GET to helloController retuns <h1></h1>", async () => {
//     const testClient = await superoak(app);
//     let response = await testClient.get("/");
//     let body = await response.text
//     asserts.assert(body.includes("<h2>Welcome to Lifetrack</h2>"))
// });

