import { executeQuery } from "../database/database.js";

const getNews = async () => {
    const res = await executeQuery("SELECT * FROM news");
    // console.log(res)
    if (res && res.rowCount > 0) {
        return res.rowsOfObjects();
    }

    return 'No news available';
}

const getSingleNews = async (id) => {
    const res = await executeQuery("SELECT * FROM news WHERE id=($1);", id);
    if (res && res.rowCount > 0) {
        return res.rowsOfObjects()[0];
    }

    return 'No news available';
}

const deleteSingleNews = async (id) => {
    await executeQuery("DELETE FROM news WHERE id=($1);", id);
    // if (res && res.rowCount > 0) {
    //     return res.rowsOfObjects()[0].message;
    // }

    // return 'No messages available';
}

const setNews = async (title, content) => {
    await executeQuery("INSERT INTO news (title, content) VALUES ($1, $2);", title, content);
}

export { getNews, setNews, getSingleNews, deleteSingleNews };