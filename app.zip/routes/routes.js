import { Router } from '../deps.js'
import { news, singleNews } from './controllers/newsController.js'
import * as helloApi from './apis/helloApi.js'
import * as newsApi from './apis/newsApi.js'

const router = new Router();

router.get('/', news);
router.get('/news/:id', singleNews);

router.get('/api/hello', helloApi.getHello);
router.post('/api/hello', helloApi.setHello);

router.get('/api/news', newsApi.getNews);
router.get('/api/news/:id', newsApi.getSingleNews);
router.post('/api/news', newsApi.setNews);
router.delete('/api/news/:id', newsApi.deleteSingleNews);

export { router }