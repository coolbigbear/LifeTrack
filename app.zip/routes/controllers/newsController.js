import { getNews, getSingleNews } from "../../services/newsService.js";

const news = async ({ render }) => {
    render('index.ejs', { data: await getNews() });
};

const singleNews = async ({ params, render }) => {
    let id = params.id
    render('news-item.ejs', { data: await getSingleNews(id) });
};

export { news, singleNews };