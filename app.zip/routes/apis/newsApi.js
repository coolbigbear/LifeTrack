import * as newsService from "../../services/newsService.js";

const getNews = async ({ response }) => {
    // console.log("GET news API called")
    response.body = await newsService.getNews();
};

const getSingleNews = async ({ params, response }) => {
    //get ID
    let id = params.id
    console.log(id)
    response.body = await newsService.getSingleNews(id);
};

const deleteSingleNews = async ({ params, response }) => {
    //get ID
    let id = params.id
    await newsService.deleteSingleNews(id)
    response.status = 200;
};

const setNews = async ({ request, response }) => {
    const body = request.body({ type: 'json' });
    const document = await body.value;
    newsService.setNews(document.title, document.content);
    response.status = 200;
};

export { getNews, setNews, getSingleNews, deleteSingleNews };