
const log = async ({ request }, next) => {
    console.log(`${request.url.pathname} - ${request.method}`);
    await next();
};

const errorMiddleware = async (context, next) => {
    try {
        await next();
    } catch (e) {
        console.log(e);
    }
}

const paywall = async ({ response, request, session }, next) => {
    if (request.url.pathname.includes("/news/")) {
        let noOfRequests = await session.get('numberOfRequests')
        console.log(noOfRequests)
        if (!noOfRequests) {
            console.log("Session not set!")
            await session.set('numberOfRequests', 1)
        } else {
            console.log("Session set!")
            if (noOfRequests > 3) {
                //Activate paywall
                return response.body = "This content is only for paying users."
            }
        }
        noOfRequests = await session.get('numberOfRequests')
        noOfRequests = Number(noOfRequests) + 1
        await session.set('numberOfRequests', noOfRequests)
        await next()
    } else {
        await next()
    }
}

export { log, errorMiddleware, paywall }