let config = {};

if (Deno.env.get('TEST_ENVIRONMENT')) {
    config.database = {};
} else {
    config.database = {
        hostname: "kandula.db.elephantsql.com",
        database: "yvbpbezq",
        user: "yvbpbezq",
        password: "R64Bx83Lf-Z3XHR_xhwzk8KpIyAX1Y4K",
        port: 5432
    };
}

export { config }; 